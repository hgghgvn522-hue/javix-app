import 'package:flutter/material.dart';

import '../../core/theme/javix_theme.dart';

/// The central gold microphone ring shown on the home screen.
class VoiceButton extends StatelessWidget {
  final bool listening;
  final VoidCallback onTap;

  const VoiceButton({super.key, required this.listening, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        width: 180,
        height: 180,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(
            color: JavixColors.gold,
            width: listening ? 5 : 2.5,
          ),
          boxShadow: listening
              ? [BoxShadow(color: JavixColors.gold.withOpacity(0.35), blurRadius: 40)]
              : [],
        ),
        child: Center(
          child: Icon(
            Icons.graphic_eq,
            size: 56,
            color: listening ? JavixColors.gold : JavixColors.textPrimary,
          ),
        ),
      ),
    );
  }
}
