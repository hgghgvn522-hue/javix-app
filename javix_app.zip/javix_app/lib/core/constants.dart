class AppConstants {
  AppConstants._();

  static const String appName = 'JAVIX';
  static const String appTagline = 'YOUR PERSONAL ASSISTANT';

  // Default reminder lead time (e.g. alert 30 minutes before the event).
  static const Duration defaultReminderLead = Duration(minutes: 30);

  // SharedPreferences keys.
  static const String prefRole = 'javix_role';
  static const String prefReadAloud = 'javix_read_aloud';
  static const String prefLeadMinutes = 'javix_lead_minutes';

  // MQTT (home devices) defaults - override in Developer Edition.
  static const String mqttDefaultHost = '192.168.1.10';
  static const int mqttDefaultPort = 1883;
}
