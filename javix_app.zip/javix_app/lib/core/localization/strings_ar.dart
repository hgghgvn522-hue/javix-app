/// Central Arabic strings so both editions stay consistent.
class S {
  S._();

  static const String home = 'الرئيسية';
  static const String record = 'السجل';
  static const String ai = 'الذكاء الاصطناعي';
  static const String profile = 'الملف الشخصي';

  static const String cameraSearch = 'الكاميرا';
  static const String cameraSearchSub = 'التقاط الصور';
  static const String webSearch = 'البحث';
  static const String webSearchSub = 'في الإنترنت';
  static const String notes = 'الملاحظات';
  static const String notesSub = 'وتنظيم المهام';
  static const String location = 'الملاحة';
  static const String locationSub = 'والخرائط';
  static const String apps = 'التطبيقات';
  static const String appsSub = 'وإدارة الهاتف';

  static const String listening = 'في انتظار أمرك...';
  static const String recentCommands = 'آخر الأوامر';

  static const String devices = 'الأجهزة المنزلية';
  static const String reminders = 'التذكيرات والمواعيد';
  static const String addReminder = 'إضافة تذكير';
  static const String reminderLeadLabel = 'التنبيه قبل الموعد';

  static const String readAloud = 'قراءة النتائج صوتياً';
  static const String developerMode = 'وضع المطور';

  static const String devDashboard = 'لوحة تحكم المطور';
  static const String devPermissions = 'إدارة الأذونات';
  static const String devUpdates = 'نشر التحديثات';
  static const String devLogs = 'سجلات التشخيص';

  static const String permissionDenied = 'لا تملك صلاحية لهذا الإجراء';
  static const String switchToUser = 'العودة لنسخة المستخدم';
}
