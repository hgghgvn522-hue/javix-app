import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/constants.dart';
import '../../core/permissions/role.dart';

/// Session-level auth + role resolution.
/// In production, replace [login] with your backend auth (Firebase Auth, JWT...).
class PermissionService extends ChangeNotifier {
  Role _role = Role.user;
  String? _userId;

  Role get role => _role;
  bool get isDeveloper => _role.edition == AppEdition.developer;
  String? get userId => _userId;

  Future<void> restore() async {
    final prefs = await SharedPreferences.getInstance();
    final stored = prefs.getString(AppConstants.prefRole);
    _role = stored == 'developer' ? Role.developer : Role.user;
    notifyListeners();
  }

  /// Demo login: developers authenticate with a special code.
  Future<bool> login({required String userId, String? devCode}) async {
    // In production: call your backend and verify a signed token instead.
    if (devCode != null && devCode == 'JAVIX-DEV-2026') {
      _role = Role.developer;
    } else {
      _role = Role.user;
    }
    _userId = userId;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(AppConstants.prefRole, _role.edition.name);
    notifyListeners();
    return true;
  }

  Future<void> logout() async {
    _role = Role.user;
    _userId = null;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(AppConstants.prefRole);
    notifyListeners();
  }

  void require(AppPermission p) {
    if (!_role.can(p)) {
      throw PermissionDeniedException(p);
    }
  }
}

class PermissionDeniedException implements Exception {
  final AppPermission permission;
  PermissionDeniedException(this.permission);

  @override
  String toString() => 'Permission denied: $permission';
}
