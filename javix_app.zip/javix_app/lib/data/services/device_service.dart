import 'package:flutter/foundation.dart';
import 'package:mqtt_client/mqtt_client.dart';
import 'package:mqtt_client/mqtt_server_client.dart';

import '../../core/constants.dart';
import '../models/device.dart';

/// Controls smart home devices. Uses a local in-memory backend by default;
/// set [useMqtt] (Developer Edition) to drive a real broker.
class DeviceService extends ChangeNotifier {
  final List<Device> _devices = [
    Device(id: 'light.living', name: 'إضاءة الصالة', type: DeviceType.light, room: 'الصالة', isOn: true),
    Device(id: 'ac.bedroom', name: 'مكيف الغرفة', type: DeviceType.ac, room: 'الغرفة', level: 22),
    Device(id: 'tv.living', name: 'شاشة الصالة', type: DeviceType.tv, room: 'الصالة'),
  ];

  List<Device> get devices => List.unmodifiable(_devices);

  MqttServerClient? _client;
  bool _useMqtt = false;
  bool get useMqtt => _useMqtt;

  Future<void> connectMqtt({String? host}) async {
    final client = MqttServerClient.withPort(
      host ?? AppConstants.mqttDefaultHost,
      'javix_${DateTime.now().millisecondsSinceEpoch}',
      AppConstants.mqttDefaultPort,
    );
    client.keepAlivePeriod = 30;
    client.logging(on: false);
    final status = await client.connect();
    if (status?.state == MqttConnectionState.connected) {
      _client = client;
      _useMqtt = true;
      notifyListeners();
    } else {
      client.disconnect();
      throw StateError('تعذر الاتصال بوسيط MQTT');
    }
  }

  /// Execute a natural-language style command, e.g. "شغّل إضاءة الصالة".
  String runVoiceCommand(String command) {
    final cmd = command.trim();
    for (final d in _devices) {
      if (cmd.contains(d.name) || cmd.contains(d.room)) {
        if (cmd.contains('شغل') || cmd.contains('افتح') || cmd.contains('on')) {
          _apply(d, isOn: true);
          return 'تم تشغيل ${d.name}';
        }
        if (cmd.contains('طفي') || cmd.contains('أطفئ') || cmd.contains('وقف') || cmd.contains('off')) {
          _apply(d, isOn: false);
          return 'تم إطفاء ${d.name}';
        }
      }
    }
    return 'لم أفهم الأمر، حاول مرة أخرى';
  }

  void toggle(Device d) => _apply(d, isOn: !d.isOn);

  void setLevel(Device d, int level) => _apply(d, level: level);

  void _apply(Device d, {bool? isOn, int? level}) {
    d.isOn = isOn ?? d.isOn;
    d.level = level ?? d.level;
    _publish(d);
    notifyListeners();
  }

  void _publish(Device d) {
    final c = _client;
    if (c == null || !_useMqtt) return;
    final payload = '{"state":"${d.isOn ? "ON" : "OFF"}","level":${d.level}}';
    final builder = MqttClientPayloadBuilder()..addString(payload);
    c.publishMessage('javix/${d.id}/set', MqttQos.atLeastOnce, builder.payload!);
  }
}
