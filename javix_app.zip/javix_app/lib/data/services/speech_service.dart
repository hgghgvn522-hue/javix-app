import 'package:flutter/foundation.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart';

/// Speech input (STT) + spoken output (TTS).
/// The user chooses per-result whether the answer is shown on screen
/// or read aloud - both paths go through this service.
class SpeechService extends ChangeNotifier {
  final SpeechToText _stt = SpeechToText();
  final FlutterTts _tts = FlutterTts();

  bool _listening = false;
  bool get isListening => _listening;

  String _lastHeard = '';
  String get lastHeard => _lastHeard;

  Future<bool> init() async {
    await _tts.setLanguage('ar-SA');
    await _tts.setSpeechRate(0.45);
    final available = await _stt.initialize();
    notifyListeners();
    return available;
  }

  Future<void> listen(void Function(String text) onResult) async {
    if (_listening) return;
    final available = await _stt.initialize();
    if (!available) return;
    _listening = true;
    notifyListeners();
    await _stt.listen(
      localeId: 'ar_SA',
      listenMode: ListenMode.confirmation,
      onResult: (r) {
        _lastHeard = r.recognizedWords;
        if (r.finalResult) {
          _listening = false;
          notifyListeners();
          onResult(_lastHeard);
        }
      },
    );
  }

  Future<void> stop() async {
    await _stt.stop();
    _listening = false;
    notifyListeners();
  }

  /// Read a result aloud (user chose voice output).
  Future<void> speak(String text) => _tts.speak(text);

  Future<void> stopSpeaking() => _tts.stop();
}
