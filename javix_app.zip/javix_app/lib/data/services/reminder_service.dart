import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;

import '../models/reminder.dart';

/// Schedules reminders with a configurable lead time (alert X minutes
/// before the event) plus a repeat option.
class ReminderService extends ChangeNotifier {
  final FlutterLocalNotificationsPlugin _notifications =
      FlutterLocalNotificationsPlugin();

  final List<Reminder> _reminders = [];
  List<Reminder> get reminders => List.unmodifiable(_reminders);

  Future<void> init() async {
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    await _notifications.initialize(const InitializationSettings(android: android));
    await _notifications
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.requestNotificationsPermission();
  }

  Future<int> add(Reminder r) async {
    final id = DateTime.now().millisecondsSinceEpoch ~/ 1000;
    final stored = Reminder(
      id: id,
      title: r.title,
      dueAt: r.dueAt,
      leadTime: r.leadTime,
      repeatDaily: r.repeatDaily,
    );
    _reminders.add(stored);
    await _schedule(stored);
    notifyListeners();
    return id;
  }

  Future<void> remove(int id) async {
    _reminders.removeWhere((r) => r.id == id);
    await _notifications.cancel(id);
    notifyListeners();
  }

  Future<void> _schedule(Reminder r) async {
    if (r.id == null) return;
    when() => tz.TZDateTime.from(r.alertAt, tz.local);
    const details = NotificationDetails(
      android: AndroidNotificationDetails(
        'javix_reminders', 'التذكيرات',
        importance: Importance.high,
        priority: Priority.high,
      ),
    );
    if (r.repeatDaily) {
      await _notifications.zonedSchedule(
        r.id!, 'تذكير: ${r.title}', 'الموعد اليوم ${r.dueAt.hour}:${r.dueAt.minute.toString().padLeft(2, '0')}',
        when(), details,
        androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
        uiLocalNotificationDateInterpretation: null,
        matchDateTimeComponents: DateTimeComponents.time,
      );
    } else {
      await _notifications.zonedSchedule(
        r.id!, 'تذكير: ${r.title}', 'بعد ${r.leadTime.inMinutes} دقيقة يبدأ موعدك',
        when(), details,
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      );
    }
  }
}
