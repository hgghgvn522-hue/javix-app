import 'dart:io';

import 'package:camera/camera.dart';
import 'package:flutter/foundation.dart';
import 'package:google_mlkit_object_detection/google_mlkit_object_detection.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';

import '../models/search_result.dart';

/// Camera search: point the phone at text or an object and get an
/// instant AI analysis. Results are delivered to the AR overlay layer
/// or spoken via TTS depending on the user's choice.
class VisionService extends ChangeNotifier {
  CameraController? _controller;
  CameraController? get controller => _controller;

  final _textRecognizer = TextRecognizer(script: TextRecognitionScript.latin);
  ObjectDetector? _objectDetector;

  List<CameraDescription> _cameras = [];
  bool get isReady => _controller != null && _controller!.value.isInitialized;

  Future<void> init() async {
    _cameras = await availableCameras();
    final back = _cameras.firstWhere(
      (c) => c.lensDirection == CameraLensDirection.back,
      orElse: () => _cameras.first,
    );
    _controller = CameraController(back, ResolutionPreset.medium, enableAudio: false);
    await _controller!.initialize();

    // Default on-device object detector (Google's bundled model).
    final options = ObjectDetectorOptions(
      mode: DetectionMode.stream,
      classifyObjects: true,
      multipleObjects: true,
    );
    _objectDetector = ObjectDetector(options: options);
    notifyListeners();
  }

  /// Point camera at text (e.g. a dollar price board) -> OCR.
  Future<List<SearchResult>> analyzeTextFrame() async {
    if (!isReady) return [];
    final image = await _controller!.takePicture();
    final input = InputImage.fromFile(File(image.path));
    final recognized = await _textRecognizer.processImage(input);
    await File(image.path).delete().catchError((_) => File(image.path));
    if (recognized.text.trim().isEmpty) {
      return [const SearchResult(label: 'لا يوجد نص', detail: 'وجّه الكاميرا نحو النص بوضوح')];
    }
    return [
      SearchResult(label: 'النص المقروء', detail: recognized.text.trim()),
    ];
  }

  /// Point camera at an object -> on-device object detection.
  Future<List<SearchResult>> analyzeObjectFrame() async {
    if (!isReady || _objectDetector == null) return [];
    final image = await _controller!.takePicture();
    final input = InputImage.fromFile(File(image.path));
    final objects = await _objectDetector!.processImage(input);
    await File(image.path).delete().catchError((_) => File(image.path));
    if (objects.isEmpty) {
      return [const SearchResult(label: 'لم يتم التعرف', detail: 'لم أجد كائناً واضحاً في الصورة')];
    }
    return objects
        .map((o) => SearchResult(
              label: o.labels.isNotEmpty ? o.labels.first.text : 'كائن',
              detail: 'ثقة ${((o.labels.isNotEmpty ? o.labels.first.confidence : 0) * 100).toStringAsFixed(0)}٪',
              confidence: o.labels.isNotEmpty ? o.labels.first.confidence : null,
            ))
        .toList();
  }

  Future<void> disposeCamera() async {
    await _controller?.dispose();
    _controller = null;
    notifyListeners();
  }

  Future<void> dispose() async {
    await disposeCamera();
    await _textRecognizer.close();
    await _objectDetector?.close();
  }
}
