import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'core/permissions/permission_service.dart';
import 'core/theme/javix_theme.dart';
import 'data/services/device_service.dart';
import 'data/services/reminder_service.dart';
import 'data/services/search_service.dart';
import 'data/services/speech_service.dart';
import 'features/user/home/user_home_screen.dart';
import 'features/developer/dev_dashboard_screen.dart';

/// Root widget. Edition is resolved once from [PermissionService];
/// each edition gets a completely separate navigation tree.
class JavixApp extends StatelessWidget {
  const JavixApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => PermissionService()..restore()),
        ChangeNotifierProvider(create: (_) => DeviceService()),
        ChangeNotifierProvider(create: (_) => ReminderService()..init()),
        ChangeNotifierProvider(create: (_) => SearchService()),
        ChangeNotifierProvider(create: (_) => SpeechService()..init()),
      ],
      child: MaterialApp(
        title: 'JAVIX',
        debugShowCheckedModeBanner: false,
        theme: JavixTheme.dark,
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar'), Locale('en')],
        home: Consumer<PermissionService>(
          builder: (_, auth, __) => auth.isDeveloper
              ? const DevDashboardScreen()
              : const UserHomeScreen(),
        ),
      ),
    );
  }
}
