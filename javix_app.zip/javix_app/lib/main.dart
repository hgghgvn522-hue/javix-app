import 'package:flutter/material.dart';
import 'package:timezone/data/latest_all.dart' as tz;

import 'app.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  tz.initializeTimeZones();
  runApp(const JavixApp());
}
