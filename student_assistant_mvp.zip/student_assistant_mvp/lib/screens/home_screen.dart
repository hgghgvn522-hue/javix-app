import 'package:flutter/material.dart';
import 'subjects_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('مساعد الطالب العراقي'),
          centerTitle: true,
          backgroundColor: Colors.transparent,
          elevation: 0,
        ),
        body: SafeArea(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(20, 10, 20, 28),
            children: [
              const Text(
                'أهلاً بك 👋',
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 6),
              Text(
                'خلّينا نخلي دراستك أسهل.',
                style: TextStyle(fontSize: 16, color: Colors.grey.shade700),
              ),
              const SizedBox(height: 24),
              _HeroCard(onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const SubjectsScreen()),
                  )),
              const SizedBox(height: 18),
              const Text('الوصول السريع', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(child: _QuickCard(icon: Icons.menu_book_rounded, title: 'موادي', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SubjectsScreen())))),
                  const SizedBox(width: 12),
                  Expanded(child: _QuickCard(icon: Icons.quiz_rounded, title: 'اختبار', onTap: () => _comingSoon(context))),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(child: _QuickCard(icon: Icons.history_rounded, title: 'نتائجي', onTap: () => _comingSoon(context))),
                  const SizedBox(width: 12),
                  Expanded(child: _QuickCard(icon: Icons.timer_outlined, title: 'مذاكرتي', onTap: () => _comingSoon(context))),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _comingSoon(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('هذه الميزة سنبنيها في الخطوة القادمة 🚀')),
    );
  }
}

class _HeroCard extends StatelessWidget {
  final VoidCallback onTap;
  const _HeroCard({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: const Color(0xFF0B2A5B),
      borderRadius: BorderRadius.circular(24),
      child: InkWell(
        borderRadius: BorderRadius.circular(24),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(22),
          child: Row(
            children: [
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('ابدأ دراستك', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w800)),
                    SizedBox(height: 8),
                    Text('أضف مادة وابدأ أول درس أو اختبار.', style: TextStyle(color: Color(0xFFD7E5FF), fontSize: 14, height: 1.4)),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              Container(
                width: 58,
                height: 58,
                decoration: BoxDecoration(color: const Color(0xFF168AF0), borderRadius: BorderRadius.circular(18)),
                child: const Icon(Icons.arrow_back_rounded, color: Colors.white, size: 30),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _QuickCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final VoidCallback onTap;
  const _QuickCard({required this.icon, required this.title, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
          child: Column(
            children: [
              Icon(icon, size: 34, color: const Color(0xFF168AF0)),
              const SizedBox(height: 9),
              Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
            ],
          ),
        ),
      ),
    );
  }
}
