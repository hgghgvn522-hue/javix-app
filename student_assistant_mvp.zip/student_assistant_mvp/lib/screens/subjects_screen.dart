import 'package:flutter/material.dart';

class SubjectsScreen extends StatefulWidget {
  const SubjectsScreen({super.key});

  @override
  State<SubjectsScreen> createState() => _SubjectsScreenState();
}

class _SubjectsScreenState extends State<SubjectsScreen> {
  final List<String> _subjects = [];

  void _addSubject() {
    final controller = TextEditingController();
    showDialog<void>(
      context: context,
      builder: (context) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text('إضافة مادة'),
          content: TextField(
            controller: controller,
            autofocus: true,
            decoration: const InputDecoration(hintText: 'مثلاً: أحياء'),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
            FilledButton(
              onPressed: () {
                final name = controller.text.trim();
                if (name.isNotEmpty) setState(() => _subjects.add(name));
                Navigator.pop(context);
              },
              child: const Text('إضافة'),
            ),
          ],
        ),
      ),
    ).then((_) => controller.dispose());
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('موادي')),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: _addSubject,
          icon: const Icon(Icons.add),
          label: const Text('إضافة مادة'),
        ),
        body: _subjects.isEmpty
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(32),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.menu_book_rounded, size: 72, color: Colors.blue.shade300),
                      const SizedBox(height: 16),
                      const Text('ما عندك مواد بعد', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 8),
                      Text('أضف أول مادة حتى نبدأ نبني عليها الدروس والاختبارات.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey.shade700)),
                    ],
                  ),
                ),
              )
            : ListView.separated(
                padding: const EdgeInsets.all(18),
                itemCount: _subjects.length,
                separatorBuilder: (_, __) => const SizedBox(height: 10),
                itemBuilder: (_, index) => Card(
                  child: ListTile(
                    leading: const CircleAvatar(child: Icon(Icons.book_rounded)),
                    title: Text(_subjects[index], style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: const Text('0 درس • 0 اختبار'),
                    trailing: const Icon(Icons.chevron_left_rounded),
                    onTap: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('شاشة المادة سنبنيها بالخطوة التالية.'))),
                  ),
                ),
              ),
      ),
    );
  }
}
